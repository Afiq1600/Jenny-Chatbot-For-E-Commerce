class Chatbox {
    constructor() {
        this.args = {
            openButton: document.querySelector('.chatbox__button'),
            chatBox: document.querySelector('.chatbox__support'),
            sendButton: document.querySelector('.send__button')
        }

        this.state = false;
        this.messages = [];
    }

    display() {
        const {openButton, chatBox, sendButton} = this.args;

        openButton.addEventListener('click', () => this.toggleState(chatBox))

        sendButton.addEventListener('click', () => this.onSendButton(chatBox))

        const node = chatBox.querySelector('input');
        node.addEventListener("keyup", ({key}) => {
            if (key === "Enter") {
                this.onSendButton(chatBox)
            }
        })
    }

    toggleState(chatbox) {
        this.state = !this.state;

        // show or hides the box
        if(this.state) {
            chatbox.classList.add('chatbox--active')
        } else {
            chatbox.classList.remove('chatbox--active')
        }
    }

    onSendButton(chatbox) {
        var textField = chatbox.querySelector('input');
        let text1 = textField.value
        if (text1 === "") {
            return;
        }

        let msg1 = { name: "User", message: text1 }
        this.messages.push(msg1);

        fetch('http://127.0.0.1:5000/predict', {
            method: 'POST',
            body: JSON.stringify({ message: text1 }),
            mode: 'cors',
            headers: {
              'Content-Type': 'application/json'
            },
          })
          .then(r => r.json())
          .then(r => {
            let msg2 = { name: "Jenny", message: r.answer };
            this.messages.push(msg2);
            this.updateChatText(chatbox)
            textField.value = ''

        }).catch((error) => {
            console.error('Error:', error);
            this.updateChatText(chatbox)
            textField.value = ''
          });
    }

    updateChatText(chatbox) {
        var html = '';
        this.messages.slice().reverse().forEach(function(item, index) {
            if (item.name === "Jenny")
            {
                html += '<div class="messages__item messages__item--visitor">' + item.message + '</div>'
            }
            else
            {
                html += '<div class="messages__item messages__item--operator">' + item.message + '</div>'
            }
          });

        const chatmessage = chatbox.querySelector('.chatbox__messages');
        chatmessage.innerHTML = html;
    }
}


const chatbox = new Chatbox();
chatbox.display();




window.onload = async () => {

    const chatInput = $(".chat-input").val();
 
    
  $.ajax({
    url: "https://javascript-chatbot.vercel.app/api/allquestions",
    success: (data) => {
      data.forEach((qus) => {
        $(".questions.container").append(`
            <div class="question">
              <p>${qus}</p>
            </div>
            `);
      });
    },
  });

  const toogleShowSuggestions = () => {
    if ($("main").css("display") === "none") {
      $(".all-questions").hide();
      $("header img").attr(
        "src",
        "https://javascript-chatbot.vercel.app/src/images/chat_icon.png",
      );
      $("main").show();
      $("footer").show();
    } else {
      $(".all-questions").show();
      $("header img").attr(
        "src",
        "https://javascript-chatbot.vercel.app/src/images/close.png",
      );
      $("main").hide();
      $("footer").hide();
    }
  };

  $("#toogle-chat").on("click", () => {
    toogleShowSuggestions();
  });

  window.onresize = () => {
    if (window.innerHeight < 580) {
      $("header").css("top", "-4em");
    } else {
      $("header").css("top", "0vh");
    }
  };

  $("#chat-form").submit((e) => {
    e.preventDefault();
    submitForm();
  });

  const typed = new Typed(".chat-input", {
    strings: [
        "I want to create an account",
        "I do have complaint I would like to make.",
        "Which items do you have?",
        "Do they come in different colors.",
        "Do you accept Mastercard?",
        "How long does delivery take?",
        "I got a wrong model, I want to return.",
        "What is your refund policy?",
        "What is your refund policy?",
        "I just want to see how long the promo code last for.",
        "Can I do change item on my order.",
        "I do not know what happen to my cart, it like not responding.",
        "I want an extension for my shopping service.",
        "May I know price of overnight shipping?",
        "How early does your local store open?",
        "The website is error?",
        "My Bestie's birthday is coming up, can my item gift wrapped?",
        "Can I have the tracking number?",
        "The price for smarphone is so expensive",
        "Shipping cost is expensive",
        "You're out of stock on items that I want to puchase",
        "Do you have smartphone with dual sim?",
        "Do your smartphone product support wifi 6?",
        "Do your smartphone product support bluetooth 5.0?",
        "How long does the average battery life of the smartphone?",
        "Can you show me delivery options?",
        "Are there any gift cards available?",
        "Can I change my order?",
        "Can you check my orders?",
        "Do you have any discounts?",
        "What should I call you?"
    ],
    typeSpeed: 60,
    backSpeed: 30,
    backDelay: 1500,
    showCursor: true,
    cursorChar: "|",
    attr: "placeholder",
    loop: true,
    bindInputFocusEvents: false,
    shuffle: true,
  });
};
