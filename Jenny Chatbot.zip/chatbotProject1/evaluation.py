import pickle
from keras.models import load_model

model = load_model('chatbot_model.h5')

words = pickle.load(open('words.pkl','rb'))
classes = pickle.load(open('classes.pkl','rb'))



loss, accuracy = model.evaluate(train_x, train_y)
print("Loss:", loss)
print("Accuracy:", accuracy)